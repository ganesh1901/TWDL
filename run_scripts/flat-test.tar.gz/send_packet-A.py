#!/usr/bin/python

import os
import sys
import struct
import time

import flatbuffers
import ViewController.Interface_Type
import ViewController.IdentifyHardwareInterface
import ViewController.Mil_1553
import ViewController.IP_RRU
import ViewController.USB_RRU
import ViewController.Transaction
import struct

global rsp_fd


def PrepareObject(interface_type, payload):
    #print 'faltc ', interface_type, '     ', payload
    try:
        builder = flatbuffers.Builder(512)
        if interface_type == 'IPCARD':
            ViewController.IP_RRU.IP_RRUStart(builder)
            if payload[0] == 1:
                ViewController.IP_RRU.IP_RRUAddIType(builder, ViewController.Interface_Type.Interface_Type().DOP)
            elif payload[0] == 0:
                ViewController.IP_RRU.IP_RRUAddIType(builder, ViewController.Interface_Type.Interface_Type().DIP)
            else:
                ViewController.IP_RRU.IP_RRUAddIType(builder, ViewController.Interface_Type.Interface_Type().ADC)

            ViewController.IP_RRU.IP_RRUAddSlot(builder, payload[1])
            ViewController.IP_RRU.IP_RRUAddPort(builder, payload[2])
            ViewController.IP_RRU.IP_RRUAddChannel(builder, payload[3])
            ViewController.IP_RRU.IP_RRUAddValue(builder, payload[4])
            ors = ViewController.IP_RRU.IP_RRUEnd(builder)

            ViewController.Transaction.TransactionStart(builder)
            ViewController.Transaction.TransactionAddQueryOnInterfaceType(builder,
                                                                          ViewController.IdentifyHardwareInterface.IdentifyHardwareInterface().IP_RRU)
            ViewController.Transaction.TransactionAddQueryOnInterface(builder, ors)
            orc = ViewController.Transaction.TransactionEnd(builder)

        elif interface_type == 'MIL1553':

            ViewController.Mil_1553.Mil_1553StartPayloadVector(builder, len(payload[4]))
            for i in range(len(payload[4])):
                builder.PrependUint8(payload[4][len(payload[4]) - i - 1])
            cmd_payload = builder.EndVector(len(payload[4]))

            ViewController.Mil_1553.Mil_1553Start(builder)
            ViewController.Mil_1553.Mil_1553AddRt(builder, payload[0])
            ViewController.Mil_1553.Mil_1553AddSubaddress(builder, payload[1])
            ViewController.Mil_1553.Mil_1553AddDirection(builder, payload[2])
            ViewController.Mil_1553.Mil_1553AddWordcount(builder, payload[3])

            ViewController.Mil_1553.Mil_1553AddPayload(builder, cmd_payload)
            ViewController.Mil_1553.Mil_1553AddFrequency(builder, payload[5])
            ors = ViewController.Mil_1553.Mil_1553End(builder)

            ViewController.Transaction.TransactionStart(builder)
            ViewController.Transaction.TransactionAddQueryOnInterfaceType(builder,
                                                                          ViewController.IdentifyHardwareInterface.IdentifyHardwareInterface().Mil_1553)
            ViewController.Transaction.TransactionAddQueryOnInterface(builder, ors)
            orc = ViewController.Transaction.TransactionEnd(builder)


        elif interface_type == 'Ethernet':
            print 'In etherenet '
            #print payload[1], 'size', payload[1]

        builder.Finish(orc)
        buf = builder.Output()
        #print '^^^^^^^^^^^^^^^^^^^^size is', len(buf)

        DecodeObject(buf)


    except TypeError as type_err:
        print  '*****', type_err


def DecodeObject(buff):
    Transaction = ViewController.Transaction.Transaction.GetRootAsTransaction(buff, 0)
    if Transaction.QueryOnInterfaceType() == ViewController.IdentifyHardwareInterface.IdentifyHardwareInterface().IP_RRU:
        union_ip_rru = ViewController.IP_RRU.IP_RRU()
        union_ip_rru.Init(Transaction.QueryOnInterface().Bytes, Transaction.QueryOnInterface().Pos)

        if union_ip_rru.IType() == ViewController.Interface_Type.Interface_Type().DIP:

           print 'slot---', union_ip_rru.Slot()
           print 'port ----',  union_ip_rru.Port()
           print 'channel---', union_ip_rru.Channel()
           print 'value1', union_ip_rru.Value()

        elif union_ip_rru.IType() == ViewController.Interface_Type.Interface_Type().DOP:
            pass
        else:
            pass
    elif Transaction.QueryOnInterfaceType() == ViewController.IdentifyHardwareInterface.IdentifyHardwareInterface().Mil_1553:

        try:
            union_mil1553 = ViewController.Mil_1553.Mil_1553()
            union_mil1553.Init(Transaction.QueryOnInterface().Bytes, Transaction.QueryOnInterface().Pos)
            print 'subaddress', union_mil1553.Subaddress()
            print 'rt addrees', union_mil1553.Rt()
            print 'direction', union_mil1553.Direction()
            print 'wordcount', union_mil1553.Wordcount()
            print 'fFrequency', union_mil1553.Frequency()
            temp_list = []
            for i in range(union_mil1553.PayloadLength()):
                temp_list.append(union_mil1553.Payload(i))
            print 'payload', temp_list
        except:
            pass


temp = []
for i in range(64):
    temp.append(i)
bytes=struct.pack("=64B", *temp)
li = []
li.append(1) # rt
li.append(4) # subaddree
li.append(0) # direction
li.append(32) # worcoun
li.append(bytearray(bytes[0:64]))
li.append(1)# frequency
PrepareObject("MIL1553", li)



